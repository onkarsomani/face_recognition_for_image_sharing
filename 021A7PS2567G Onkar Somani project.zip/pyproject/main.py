import face_recognition
import cv2
import numpy as np
import pymongo

# Connect to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017")
db = client["db"]
collection = db["col"]

# Load the available images of people
person_encodings = []
person_labels = []

# Encode the available person images
for person_image in collection.find():
    img_array = np.asarray(bytearray(person_image['image_data']), dtype=np.uint8)
    img = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
    encoding = face_recognition.face_encodings(img)[0]
    person_encodings.append(encoding)
    person_labels.append(person_image.get('label', 'Unknown'))

# Load the test images from a different collection
test_collection = db["test_images"]
test_images = [test_image['image_data'] for test_image in test_collection.find()]

# Recognize people in the test images
for test_image_data in test_images:
    # Decode the test image data
    test_img_array = np.asarray(bytearray(test_image_data), dtype=np.uint8)
    test_img = cv2.imdecode(test_img_array, cv2.IMREAD_COLOR)
    rgb_img = cv2.cvtColor(test_img, cv2.COLOR_BGR2RGB)

    # Detect faces in the image
    face_locations = face_recognition.face_locations(rgb_img)
    face_encodings = face_recognition.face_encodings(rgb_img, face_locations)

    # Iterate through detected faces
    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        # Compare the face encoding with the available person encodings
        distances = face_recognition.face_distance(person_encodings, face_encoding)
        min_distance_index = np.argmin(distances)
        min_distance = distances[min_distance_index]

        # Set a threshold distance to determine if it's a match
        threshold = 0.6  # Adjust as needed

        # If the minimum distance is below the threshold, it's a match
        if min_distance <= threshold:
            label = person_labels[min_distance_index]
            cv2.rectangle(test_img, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(test_img, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 2)
        else:
            cv2.rectangle(test_img, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.putText(test_img, 'Unknown', (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 2)

    # Display the test image with recognized faces
    cv2.imshow('Test Image', test_img)
    cv2.waitKey(0)

# Wait for a key press and then close the windows
cv2.waitKey(1)
cv2.destroyAllWindows()
