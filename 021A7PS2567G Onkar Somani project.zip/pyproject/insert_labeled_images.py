import pymongo
import cv2

# Connect to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017")

# Create a new database and collection
db = client["db"]
collection = db["col"]

# Define the image file names and corresponding labels
image_labels = {
    'bezos.jpg': 'Jeff Bezos',
    'bill.jpg': 'Bill Gates',
    'elon.jpg': 'Elon Musk'
}

# Insert images into the collection
for image_file, label in image_labels.items():
    # Read the image file
    img = cv2.imread(image_file)

    # Encode the image as JPEG
    _, img_encoded = cv2.imencode('.jpg', img)
    img_data = img_encoded.tobytes()

    # Insert the image data with the corresponding label into the collection
    collection.insert_one({'image_data': img_data, 'label': label})
