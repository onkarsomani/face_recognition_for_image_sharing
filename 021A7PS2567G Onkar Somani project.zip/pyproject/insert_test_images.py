import pymongo
import cv2

# Connect to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017")

# Create a new database and collection
db = client["db"]
collection = db["test_images"]

# Insert images into the collection
for image_file in ['test1.jpg', 'test2.jpg', 'test3.jpg']:
    # Read the image file
    img = cv2.imread(image_file)

    # Encode the image as JPEG
    _, img_encoded = cv2.imencode('.jpg', img)
    img_data = img_encoded.tobytes()

    # Insert the image data into the collection
    collection.insert_one({'image_data': img_data})
